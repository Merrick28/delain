T E P I D   M O N K E Y   F O N T S
freeware fonts for a freeware world

Site:   http://www.tepidmonkey.com/
E-mail: brandon@tepidmonkey.com

Thanks for your interest in my fonts!

For help on how to unzip, unstuff or install one of my 
fonts, please visit my site at 
www.tepidmonkey.com and go to the Help section.
If you have any comments or questions, you can e-mail 
me at brandon@tepidmonkey.com and I'll try to reply as 
soon as possible.

Every week, I present a brand new original font for 
your downloading pleasure, so be sure to visit the web 
site every Sunday.

You may use this font(s) for non-commercial and 
commercial purposes. You are not allowed to sell this 
font for any fee at all. You are allowed to 
redistribute it as long as you don't charge anything 
for it and as long as you include this unaltered 
ReadMe.txt file. You may not change any aspect of the font 
file or of this file.
For the full set of terms of use (which override what 
is listed here anyway), go to www.tepidmonkey.com 
and visit the Terms section.